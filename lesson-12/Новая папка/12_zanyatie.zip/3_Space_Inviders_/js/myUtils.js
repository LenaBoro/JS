;(function(){
	window.SpaceInviders = function(el){
						
	}	
}());